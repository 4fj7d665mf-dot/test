#pragma once

#import <Foundation/Foundation.h>
#import <CoreVideo/CoreVideo.h>
#import <CoreMedia/CoreMedia.h>

NS_ASSUME_NONNULL_BEGIN

/// Initial implementation is intentionally passthrough.  It keeps interpolation
/// policy/state separate from FilterEngine so optical-flow/AI backends can be
/// added later without coupling them to color filtering.
@interface FrameInterpolator : NSObject
@property (nonatomic, readonly) double estimatedInputFPS;
@property (nonatomic, readonly) double requestedOutputFPS;
- (instancetype)initWithRequestedOutputFPS:(double)fps;
- (CVPixelBufferRef _Nullable)copyPresentationFrameFromSource:(CVPixelBufferRef)source
                                                     itemTime:(CMTime)itemTime CF_RETURNS_RETAINED;
- (void)reset;
@end

NS_ASSUME_NONNULL_END
