#import "ToggleItem.h"

@implementation VFToggleItem {
    UISwitch *_toggle;
    VFToggleChangedBlock _onChange;
}

- (instancetype)initWithTitle:(NSString *)title
                     initialOn:(BOOL)initialOn
                      onChange:(VFToggleChangedBlock)onChange {
    self = [super initWithTitle:title];
    if (!self) return nil;

    _onChange = [onChange copy];
    _toggle = [UISwitch new];
    _toggle.translatesAutoresizingMaskIntoConstraints = NO;
    _toggle.on = initialOn;
    [_toggle addTarget:self action:@selector(toggleChanged:) forControlEvents:UIControlEventValueChanged];
    [self addSubview:_toggle];

    [NSLayoutConstraint activateConstraints:@[
        [self.heightAnchor constraintEqualToConstant:42.0],
        [self.titleLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
        [self.titleLabel.centerYAnchor constraintEqualToAnchor:self.centerYAnchor],
        [_toggle.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
        [_toggle.centerYAnchor constraintEqualToAnchor:self.centerYAnchor]
    ]];
    return self;
}

- (BOOL)isOn { return _toggle.isOn; }

- (void)setOn:(BOOL)on animated:(BOOL)animated {
    [_toggle setOn:on animated:animated];
}

- (void)toggleChanged:(UISwitch *)sender {
    if (_onChange) _onChange(sender.isOn);
}

@end
