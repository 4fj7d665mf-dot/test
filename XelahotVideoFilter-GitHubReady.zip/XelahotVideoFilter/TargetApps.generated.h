// Auto-generated from TargetApps.plist. Do not edit by hand.
#pragma once

static inline NSArray<NSString *> *VFTargetBundleIDs(void) {
    static NSArray<NSString *> *ids;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        ids = @[];
    });
    return ids;
}

static inline BOOL VFBundleIDIsAllowed(NSString *bundleID) {
    if (bundleID.length == 0) return NO;
    return [VFTargetBundleIDs() containsObject:bundleID];
}
