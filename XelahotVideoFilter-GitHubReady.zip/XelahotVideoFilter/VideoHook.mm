#import "VideoHook.h"
#import "FilterEngine.h"
#import "FrameInterpolator.h"

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

@class VFPlayerSession;

@interface VFDisplayLinkProxy : NSObject
@property (nonatomic, weak) VFPlayerSession *target;
- (void)tick:(CADisplayLink *)displayLink;
@end

@interface VFPlayerSession : NSObject
@property (nonatomic, weak, readonly) AVPlayerLayer *playerLayer;
@property (nonatomic, weak, readonly) AVPlayer *player;
@property (nonatomic) VFFilterSettings settings;
- (instancetype)initWithPlayerLayer:(AVPlayerLayer *)layer settings:(VFFilterSettings)settings;
- (void)updateSettings:(VFFilterSettings)settings;
- (void)refreshPlayerReference;
- (void)resetTemporalHistory;
- (void)setApplicationActive:(BOOL)active;
- (void)invalidate;
- (void)displayTick:(CADisplayLink *)displayLink;
@end

@implementation VFDisplayLinkProxy
- (void)tick:(CADisplayLink *)displayLink {
    [self.target displayTick:displayLink];
}
@end

@implementation VFPlayerSession {
    __weak AVPlayerLayer *_playerLayer;
    __weak AVPlayer *_player;
    AVPlayerItem *_attachedItem;
    AVPlayerItemVideoOutput *_videoOutput;
    CAMetalLayer *_filteredLayer;
    FilterEngine *_engine;
    FrameInterpolator *_interpolator;
    CADisplayLink *_displayLink;
    VFDisplayLinkProxy *_displayLinkProxy;
    BOOL _applicationActive;
    BOOL _invalidated;
    float _lastRate;
}

- (instancetype)initWithPlayerLayer:(AVPlayerLayer *)layer settings:(VFFilterSettings)settings {
    self = [super init];
    if (!self) return nil;
    _playerLayer = layer;
    _player = layer.player;
    _settings = settings;
    _applicationActive = UIApplication.sharedApplication.applicationState != UIApplicationStateBackground;
    _lastRate = _player.rate;

    CAMetalLayer *filtered = [CAMetalLayer layer];
    filtered.name = @"VideoFilter.Output";
    filtered.frame = layer.bounds;
    filtered.contentsScale = UIScreen.mainScreen.scale;
    filtered.masksToBounds = YES;
    filtered.opaque = NO;
    filtered.hidden = YES;
    // A sublayer is above AVPlayerLayer's video content but below later overlay sublayers.
    [layer insertSublayer:filtered atIndex:0];
    _filteredLayer = filtered;

    _engine = [[FilterEngine alloc] initWithMetalLayer:filtered];
    if (!_engine) {
        [_filteredLayer removeFromSuperlayer];
        return nil;
    }
    _engine.settings = settings;
    _engine.videoGravity = layer.videoGravity ?: AVLayerVideoGravityResizeAspect;

    NSInteger maxFPS = MAX(30, UIScreen.mainScreen.maximumFramesPerSecond);
    _interpolator = [[FrameInterpolator alloc] initWithRequestedOutputFPS:maxFPS];

    _displayLinkProxy = [VFDisplayLinkProxy new];
    _displayLinkProxy.target = self;
    _displayLink = [CADisplayLink displayLinkWithTarget:_displayLinkProxy selector:@selector(tick:)];
    if (@available(iOS 15.0, *)) {
        float maximum = (float)MAX(30, UIScreen.mainScreen.maximumFramesPerSecond);
        float minimum = MIN(30.0f, maximum);
        _displayLink.preferredFrameRateRange = CAFrameRateRangeMake(minimum, maximum, maximum);
    } else {
        _displayLink.preferredFramesPerSecond = UIScreen.mainScreen.maximumFramesPerSecond;
    }
    [_displayLink addToRunLoop:NSRunLoop.mainRunLoop forMode:NSRunLoopCommonModes];

    [self updateCaptureState];
    return self;
}

- (AVPlayerLayer *)playerLayer { return _playerLayer; }
- (AVPlayer *)player { return _player; }

- (void)dealloc {
    [_displayLink invalidate];
    [self detachVideoOutput];
    [_filteredLayer removeFromSuperlayer];
}

- (NSDictionary *)videoOutputPixelBufferAttributes {
    return @{ (NSString *)kCVPixelBufferMetalCompatibilityKey : @YES };
}

- (void)attachVideoOutputToCurrentItem {
    AVPlayer *player = _player;
    AVPlayerItem *item = player.currentItem;
    if (!item || item == _attachedItem) return;

    [self detachVideoOutput];
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    AVPlayerItemVideoOutput *output = [[AVPlayerItemVideoOutput alloc] initWithPixelBufferAttributes:[self videoOutputPixelBufferAttributes]];
#pragma clang diagnostic pop
    if (!output) return;

    @try {
        output.suppressesPlayerRendering = NO;
        [item addOutput:output];
        [output requestNotificationOfMediaDataChangeWithAdvanceInterval:0.03];
        _videoOutput = output;
        _attachedItem = item;
    } @catch (__unused NSException *exception) {
        _videoOutput = nil;
        _attachedItem = nil;
    }
    [self resetTemporalHistory];
}

- (void)detachVideoOutput {
    if (_attachedItem && _videoOutput) {
        @try { [_attachedItem removeOutput:_videoOutput]; }
        @catch (__unused NSException *exception) {}
    }
    _attachedItem = nil;
    _videoOutput = nil;
}

- (void)refreshPlayerReference {
    AVPlayer *current = _playerLayer.player;
    if (_player != current) {
        [self detachVideoOutput];
        _player = current;
        _lastRate = current.rate;
        [self resetTemporalHistory];
    }
    [self updateCaptureState];
}

- (void)updateSettings:(VFFilterSettings)settings {
    _settings = settings;
    _engine.settings = settings;
    [self updateCaptureState];
}

- (void)updateCaptureState {
    if (_invalidated) return;
    BOOL needsFiltering = VFFilterSettingsHasVisibleEffect(_settings);
    BOOL shouldRun = needsFiltering && _applicationActive && _playerLayer && _player;

    if (shouldRun) {
        [self attachVideoOutputToCurrentItem];
        _filteredLayer.hidden = NO;
        _displayLink.paused = NO;
    } else {
        _displayLink.paused = YES;
        _filteredLayer.hidden = YES;
        [self detachVideoOutput];
        [_engine resetTemporalHistory];
        [_interpolator reset];
    }
}

- (void)setApplicationActive:(BOOL)active {
    _applicationActive = active;
    if (active) [self resetTemporalHistory];
    [self updateCaptureState];
}

- (void)resetTemporalHistory {
    [_engine resetTemporalHistory];
    [_interpolator reset];
}

- (void)syncLayerGeometry {
    AVPlayerLayer *layer = _playerLayer;
    if (!layer) return;
    if (_filteredLayer.superlayer != layer) {
        [_filteredLayer removeFromSuperlayer];
        [layer insertSublayer:_filteredLayer atIndex:0];
    }
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    _filteredLayer.frame = layer.bounds;
    _filteredLayer.cornerRadius = layer.cornerRadius;
    _filteredLayer.maskedCorners = layer.maskedCorners;
    _filteredLayer.contentsScale = layer.contentsScale > 0 ? layer.contentsScale : UIScreen.mainScreen.scale;
    [CATransaction commit];
    _engine.videoGravity = layer.videoGravity ?: AVLayerVideoGravityResizeAspect;
}

- (void)displayTick:(CADisplayLink *)displayLink {
    if (_invalidated || !_applicationActive) return;

    AVPlayerLayer *layer = _playerLayer;
    if (!layer) { [self invalidate]; return; }
    [self syncLayerGeometry];

    if (_player != layer.player) [self refreshPlayerReference];
    AVPlayer *player = _player;
    if (!player) return;

    if (_attachedItem != player.currentItem) {
        [self detachVideoOutput];
        [self attachVideoOutputToCurrentItem];
        [self resetTemporalHistory];
    }
    if (!_videoOutput) return;

    float rate = player.rate;
    if (rate > 0.001f && _lastRate <= 0.001f) [self resetTemporalHistory];
    _lastRate = rate;

    CFTimeInterval hostTime = displayLink.targetTimestamp > 0.0 ? displayLink.targetTimestamp : CACurrentMediaTime();
    CMTime itemTime = [_videoOutput itemTimeForHostTime:hostTime];
    if (!CMTIME_IS_NUMERIC(itemTime)) return;
    if (![_videoOutput hasNewPixelBufferForItemTime:itemTime]) return;

    CMTime displayTime = kCMTimeInvalid;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    CVPixelBufferRef source = [_videoOutput copyPixelBufferForItemTime:itemTime itemTimeForDisplay:&displayTime];
#pragma clang diagnostic pop
    if (!source) return;

    CMTime effectiveTime = CMTIME_IS_NUMERIC(displayTime) ? displayTime : itemTime;
    CVPixelBufferRef frame = [_interpolator copyPresentationFrameFromSource:source itemTime:effectiveTime];
    CVPixelBufferRelease(source);
    if (!frame) return;

    // Keep the CAMetalLayer in the render tree so nextDrawable can succeed.
    _filteredLayer.hidden = NO;
    BOOL rendered = [_engine renderPixelBuffer:frame itemTime:effectiveTime];
    CVPixelBufferRelease(frame);

    if (rendered) {
        _filteredLayer.hidden = NO;
    } else if (!_engine.lastFrameWasSupported) {
        // Unknown pixel format, protected output, or other unsupported renderer: expose original video.
        _filteredLayer.hidden = YES;
    }
}

- (void)invalidate {
    if (_invalidated) return;
    _invalidated = YES;
    [_displayLink invalidate];
    _displayLink = nil;
    [self detachVideoOutput];
    [_engine purgeReusableResources];
    [_filteredLayer removeFromSuperlayer];
}

@end

// MARK: - Runtime hooks

typedef void (*VFSetPlayerIMP)(AVPlayerLayer *, SEL, AVPlayer *);
typedef void (*VFSeekIMP)(AVPlayer *, SEL, CMTime);
typedef void (*VFSeekCompletionIMP)(AVPlayer *, SEL, CMTime, void (^)(BOOL));
typedef void (*VFSeekToleranceIMP)(AVPlayer *, SEL, CMTime, CMTime, CMTime, void (^)(BOOL));
typedef void (*VFReplaceItemIMP)(AVPlayer *, SEL, AVPlayerItem *);

static VFSetPlayerIMP gOriginalSetPlayer = NULL;
static VFSeekIMP gOriginalSeek = NULL;
static VFSeekCompletionIMP gOriginalSeekCompletion = NULL;
static VFSeekToleranceIMP gOriginalSeekTolerance = NULL;
static VFReplaceItemIMP gOriginalReplaceItem = NULL;

static inline void VFDispatchMain(dispatch_block_t block) {
    if (NSThread.isMainThread) block();
    else dispatch_async(dispatch_get_main_queue(), block);
}

static void VFHookedSetPlayer(AVPlayerLayer *self, SEL _cmd, AVPlayer *player) {
    if (gOriginalSetPlayer) gOriginalSetPlayer(self, _cmd, player);
    __weak AVPlayerLayer *weakLayer = self;
    VFDispatchMain(^{
        AVPlayerLayer *layer = weakLayer;
        if (layer) [[VideoHook sharedInstance] registerPlayerLayer:layer];
    });
}

static void VFHookedSeek(AVPlayer *self, SEL _cmd, CMTime time) {
    if (gOriginalSeek) gOriginalSeek(self, _cmd, time);
    __weak AVPlayer *weakPlayer = self;
    VFDispatchMain(^{
        AVPlayer *player = weakPlayer;
        if (player) [[VideoHook sharedInstance] notifySeekForPlayer:player];
    });
}

static void VFHookedSeekCompletion(AVPlayer *self, SEL _cmd, CMTime time, void (^completion)(BOOL)) {
    if (gOriginalSeekCompletion) gOriginalSeekCompletion(self, _cmd, time, completion);
    __weak AVPlayer *weakPlayer = self;
    VFDispatchMain(^{
        AVPlayer *player = weakPlayer;
        if (player) [[VideoHook sharedInstance] notifySeekForPlayer:player];
    });
}

static void VFHookedSeekTolerance(AVPlayer *self, SEL _cmd, CMTime time, CMTime before, CMTime after, void (^completion)(BOOL)) {
    if (gOriginalSeekTolerance) gOriginalSeekTolerance(self, _cmd, time, before, after, completion);
    __weak AVPlayer *weakPlayer = self;
    VFDispatchMain(^{
        AVPlayer *player = weakPlayer;
        if (player) [[VideoHook sharedInstance] notifySeekForPlayer:player];
    });
}

static void VFHookedReplaceItem(AVPlayer *self, SEL _cmd, AVPlayerItem *item) {
    if (gOriginalReplaceItem) gOriginalReplaceItem(self, _cmd, item);
    __weak AVPlayer *weakPlayer = self;
    VFDispatchMain(^{
        AVPlayer *player = weakPlayer;
        if (player) [[VideoHook sharedInstance] notifyItemChangedForPlayer:player];
    });
}

static IMP VFInstallHook(Class cls, SEL selector, IMP replacement) {
    Method method = class_getInstanceMethod(cls, selector);
    if (!method) return NULL;
    return method_setImplementation(method, replacement);
}

@interface VideoHook ()
@property (nonatomic) BOOL started;
@property (nonatomic) VFFilterSettings settings;
@property (nonatomic, strong) NSMapTable<AVPlayerLayer *, VFPlayerSession *> *sessions;
@end

@implementation VideoHook

+ (instancetype)sharedInstance {
    static VideoHook *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ instance = [VideoHook new]; });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _settings = VFFilterPresetDefaults();
        _sessions = [NSMapTable weakToStrongObjectsMapTable];
    }
    return self;
}

- (void)start {
    if (self.started) return;
    self.started = YES;

    static dispatch_once_t hookOnce;
    dispatch_once(&hookOnce, ^{
        gOriginalSetPlayer = (VFSetPlayerIMP)VFInstallHook(AVPlayerLayer.class, @selector(setPlayer:), (IMP)VFHookedSetPlayer);
        gOriginalSeek = (VFSeekIMP)VFInstallHook(AVPlayer.class, @selector(seekToTime:), (IMP)VFHookedSeek);
        gOriginalSeekCompletion = (VFSeekCompletionIMP)VFInstallHook(AVPlayer.class, @selector(seekToTime:completionHandler:), (IMP)VFHookedSeekCompletion);
        gOriginalSeekTolerance = (VFSeekToleranceIMP)VFInstallHook(AVPlayer.class,
            @selector(seekToTime:toleranceBefore:toleranceAfter:completionHandler:), (IMP)VFHookedSeekTolerance);
        gOriginalReplaceItem = (VFReplaceItemIMP)VFInstallHook(AVPlayer.class,
            @selector(replaceCurrentItemWithPlayerItem:), (IMP)VFHookedReplaceItem);
    });

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(appDidBecomeActive:)
                                                 name:UIApplicationDidBecomeActiveNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(appDidEnterBackground:)
                                                 name:UIApplicationDidEnterBackgroundNotification
                                               object:nil];

    [self scanExistingPlayerLayers];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (self.started) [self scanExistingPlayerLayers];
    });
}

- (void)stop {
    if (!self.started) return;
    self.started = NO;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    for (VFPlayerSession *session in self.sessions.objectEnumerator) [session invalidate];
    [self.sessions removeAllObjects];
}

- (void)updateFilterSettings:(VFFilterSettings)settings {
    self.settings = settings;
    for (VFPlayerSession *session in self.sessions.objectEnumerator) {
        [session updateSettings:settings];
    }
}

- (void)resetTemporalHistory {
    for (VFPlayerSession *session in self.sessions.objectEnumerator) [session resetTemporalHistory];
}

- (void)registerPlayerLayer:(AVPlayerLayer *)layer {
    if (!self.started || !layer) return;
    VFPlayerSession *session = [self.sessions objectForKey:layer];
    if (!session) {
        session = [[VFPlayerSession alloc] initWithPlayerLayer:layer settings:self.settings];
        if (session) [self.sessions setObject:session forKey:layer];
    } else {
        [session refreshPlayerReference];
    }
}

- (void)notifySeekForPlayer:(AVPlayer *)player {
    if (!player) return;
    for (VFPlayerSession *session in self.sessions.objectEnumerator) {
        if (session.player == player) [session resetTemporalHistory];
    }
}

- (void)notifyItemChangedForPlayer:(AVPlayer *)player {
    if (!player) return;
    for (VFPlayerSession *session in self.sessions.objectEnumerator) {
        if (session.player == player) {
            [session refreshPlayerReference];
            [session resetTemporalHistory];
        }
    }
}

- (void)appDidBecomeActive:(NSNotification *)note {
    (void)note;
    for (VFPlayerSession *session in self.sessions.objectEnumerator) [session setApplicationActive:YES];
    [self scanExistingPlayerLayers];
}

- (void)appDidEnterBackground:(NSNotification *)note {
    (void)note;
    for (VFPlayerSession *session in self.sessions.objectEnumerator) [session setApplicationActive:NO];
}

- (void)scanLayerTree:(CALayer *)layer {
    if ([layer isKindOfClass:AVPlayerLayer.class]) {
        [self registerPlayerLayer:(AVPlayerLayer *)layer];
    }
    NSArray<CALayer *> *children = [layer.sublayers copy];
    for (CALayer *child in children) [self scanLayerTree:child];
}

- (void)scanExistingPlayerLayers {
    NSAssert(NSThread.isMainThread, @"VideoFilter scans UI on main thread");
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if (![scene isKindOfClass:UIWindowScene.class]) continue;
            for (UIWindow *window in ((UIWindowScene *)scene).windows) {
                [self scanLayerTree:window.layer];
            }
        }
    } else {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        for (UIWindow *window in UIApplication.sharedApplication.windows) [self scanLayerTree:window.layer];
#pragma clang diagnostic pop
    }
}

@end
