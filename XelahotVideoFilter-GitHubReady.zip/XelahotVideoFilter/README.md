# VideoFilter (iOS tweak)

This project uses the UI/module layout of xelahot/iOS-Mod-Menu-Base as the menu-side reference and replaces the demo mod controls with a real-time video-filter pipeline.

## What is included

- Floating `VF` button above the app UI
- Drag and saved position, restored per Bundle ID
- Safe-area and rotation clamping
- Compact translucent panel
- FILTER on/off state persistence
- Contrast: -100 ... +100 (default +15)
- Saturation: -100 ... +100 (default +5)
- Exposure: -100 ... +100 (default +5)
- Sharpen: 0 ... 100 (default +40)
- Highlights: -100 ... +100 (default +5)
- Motion Blur: 0 ... 20% (default 6%)
- RESET sets adjustment values to zero without changing FILTER on/off
- AVPlayerLayer / AVPlayerItemVideoOutput integration
- Metal processing through CVPixelBuffer -> CVMetalTextureCache -> MTLTexture
- BT.601/709/2020 metadata handling where available, full/limited range handling, SDR/PQ/HLG paths
- Temporal motion blur with previous-frame history reset on seek/item change/restart/large timestamp jump/resolution change and scene-change protection
- ProMotion-aware CADisplayLink scheduling
- FrameInterpolator kept separate and intentionally passthrough for now

## Choose target apps

Edit only `TargetApps.plist`:

```xml
<key>Bundles</key>
<array>
    <string>com.example.videoapp</string>
</array>
```

Do not edit `VideoFilter.plist` or `TargetApps.generated.h` directly; they are generated during the build.

An empty `Bundles` array intentionally means the tweak is injected into no apps.

## GitHub Actions build

The repository already contains `.github/workflows/build.yml`.

1. Put the project files at the repository root.
2. Edit `TargetApps.plist`.
3. Commit/push.
4. Open **Actions -> Build VideoFilter dylib -> Run workflow**.
5. Download the `VideoFilter-build` artifact.

The artifact contains `VideoFilter.dylib`, its SHA-256 file, and the generated `.deb` package when packaging succeeds.

## Important playback limitation

The tweak only processes frames that AVFoundation exposes to the video-output path. Unsupported/protected playback paths are not bypassed; the original video remains available and the overlay UI can still exist.

## Upstream UI reference

- https://github.com/xelahot/iOS-Mod-Menu-Base

The upstream project identifies itself as a Theos-based mod-menu base for jailbroken iOS. This project does not include the upstream demo hack logic.
