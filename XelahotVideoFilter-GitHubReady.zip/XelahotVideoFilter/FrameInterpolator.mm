#import "FrameInterpolator.h"

@implementation FrameInterpolator {
    CMTime _lastTime;
    double _estimatedInputFPS;
    double _requestedOutputFPS;
}

- (instancetype)initWithRequestedOutputFPS:(double)fps {
    self = [super init];
    if (self) {
        _requestedOutputFPS = MAX(1.0, fps);
        _lastTime = kCMTimeInvalid;
        _estimatedInputFPS = 0.0;
    }
    return self;
}

- (double)estimatedInputFPS { return _estimatedInputFPS; }
- (double)requestedOutputFPS { return _requestedOutputFPS; }

- (CVPixelBufferRef)copyPresentationFrameFromSource:(CVPixelBufferRef)source
                                           itemTime:(CMTime)itemTime {
    if (!source) return NULL;

    if (CMTIME_IS_NUMERIC(_lastTime) && CMTIME_IS_NUMERIC(itemTime)) {
        Float64 dt = CMTimeGetSeconds(CMTimeSubtract(itemTime, _lastTime));
        if (dt > 0.001 && dt < 1.0) {
            double instantaneous = 1.0 / dt;
            if (_estimatedInputFPS <= 0.0) _estimatedInputFPS = instantaneous;
            else _estimatedInputFPS = (_estimatedInputFPS * 0.90) + (instantaneous * 0.10);
        }
    }
    _lastTime = itemTime;

    // Passthrough by design.  This is not advertised as frame interpolation.
    CVPixelBufferRetain(source);
    return source;
}

- (void)reset {
    _lastTime = kCMTimeInvalid;
    _estimatedInputFPS = 0.0;
}

@end
