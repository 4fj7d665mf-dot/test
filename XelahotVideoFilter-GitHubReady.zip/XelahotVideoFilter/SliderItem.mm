#import "SliderItem.h"

@implementation VFSliderItem {
    UISlider *_slider;
    UILabel *_valueLabel;
    BOOL _percent;
    VFSliderChangedBlock _onChange;
}

- (instancetype)initWithTitle:(NSString *)title
                      minimum:(float)minimum
                      maximum:(float)maximum
                 initialValue:(float)initialValue
                      percent:(BOOL)percent
                     onChange:(VFSliderChangedBlock)onChange {
    self = [super initWithTitle:title];
    if (!self) return nil;

    _percent = percent;
    _onChange = [onChange copy];

    _valueLabel = [UILabel new];
    _valueLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _valueLabel.textAlignment = NSTextAlignmentRight;
    _valueLabel.textColor = [UIColor colorWithWhite:1.0 alpha:0.82];
    _valueLabel.font = [UIFont monospacedDigitSystemFontOfSize:12.0 weight:UIFontWeightSemibold];
    [self addSubview:_valueLabel];

    _slider = [UISlider new];
    _slider.translatesAutoresizingMaskIntoConstraints = NO;
    _slider.minimumValue = minimum;
    _slider.maximumValue = maximum;
    _slider.value = initialValue;
    _slider.continuous = YES;
    [_slider addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];
    [self addSubview:_slider];

    [NSLayoutConstraint activateConstraints:@[
        [self.heightAnchor constraintEqualToConstant:56.0],
        [self.titleLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
        [self.titleLabel.topAnchor constraintEqualToAnchor:self.topAnchor constant:2.0],
        [_valueLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
        [_valueLabel.centerYAnchor constraintEqualToAnchor:self.titleLabel.centerYAnchor],
        [_valueLabel.widthAnchor constraintEqualToConstant:58.0],
        [_slider.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
        [_slider.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
        [_slider.topAnchor constraintEqualToAnchor:self.titleLabel.bottomAnchor constant:3.0]
    ]];

    [self updateValueLabel];
    return self;
}

- (float)value { return _slider.value; }

- (void)setValue:(float)value animated:(BOOL)animated notify:(BOOL)notify {
    [_slider setValue:value animated:animated];
    [self updateValueLabel];
    if (notify && _onChange) _onChange(_slider.value);
}

- (void)sliderChanged:(UISlider *)sender {
    (void)sender;
    [self updateValueLabel];
    if (_onChange) _onChange(_slider.value);
}

- (void)updateValueLabel {
    NSInteger rounded = lroundf(_slider.value);
    _valueLabel.text = _percent ? [NSString stringWithFormat:@"%ld%%", (long)rounded]
                                : [NSString stringWithFormat:@"%+ld", (long)rounded];
}

@end
