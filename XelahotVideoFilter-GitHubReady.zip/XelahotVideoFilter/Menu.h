#pragma once
#import <Foundation/Foundation.h>
#import "VFTypes.h"

NS_ASSUME_NONNULL_BEGIN

@interface VFMenu : NSObject
+ (instancetype)sharedInstance;
- (void)start;
- (void)stop;
- (VFFilterSettings)currentSettings;
@end

NS_ASSUME_NONNULL_END
