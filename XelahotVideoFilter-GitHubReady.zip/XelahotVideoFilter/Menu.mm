#import "Menu.h"
#import "Page.h"
#import "ToggleItem.h"
#import "SliderItem.h"
#import "VideoHook.h"

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

static CGFloat const VFMenuButtonSize = 46.0;
static CGFloat const VFMenuMargin = 8.0;
static CGFloat const VFMenuPanelWidth = 310.0;
static CGFloat const VFMenuPanelHeight = 382.0;

@class VFMenu;

@interface VFMenuWindow : UIWindow
@end

@implementation VFMenuWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hit = [super hitTest:point withEvent:event];
    if (!hit || hit == self.rootViewController.view) return nil;
    return hit;
}
@end

@interface VFMenuRootController : UIViewController
@property (nonatomic, weak) VFMenu *menu;
@end

@interface VFMenu ()
@property (nonatomic, strong) VFMenuWindow *overlayWindow;
@property (nonatomic, strong) VFMenuRootController *rootController;
@property (nonatomic, strong) UIButton *floatingButton;
@property (nonatomic, strong) UIVisualEffectView *panel;
@property (nonatomic, strong) VFToggleItem *filterToggle;
@property (nonatomic, strong) VFSliderItem *contrastItem;
@property (nonatomic, strong) VFSliderItem *saturationItem;
@property (nonatomic, strong) VFSliderItem *exposureItem;
@property (nonatomic, strong) VFSliderItem *sharpenItem;
@property (nonatomic, strong) VFSliderItem *highlightsItem;
@property (nonatomic, strong) VFSliderItem *motionBlurItem;
@property (nonatomic) VFFilterSettings settings;
@property (nonatomic) BOOL started;
@property (nonatomic) BOOL panelOpen;
@property (nonatomic) BOOL restoringPosition;
@end

@interface VFMenu (Layout)
- (void)layoutOverlayAnimated:(BOOL)animated;
@end

@implementation VFMenuRootController
- (BOOL)prefersStatusBarHidden { return NO; }
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [self.menu layoutOverlayAnimated:NO];
}
@end

@implementation VFMenu

+ (instancetype)sharedInstance {
    static VFMenu *menu;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ menu = [VFMenu new]; });
    return menu;
}

- (instancetype)init {
    self = [super init];
    if (self) _settings = VFFilterPresetDefaults();
    return self;
}

- (VFFilterSettings)currentSettings { return self.settings; }

- (NSString *)defaultsPrefix {
    NSString *bundleID = NSBundle.mainBundle.bundleIdentifier ?: @"unknown";
    return [NSString stringWithFormat:@"XelahotVideoFilter.%@.", bundleID];
}

- (NSString *)defaultsKey:(NSString *)suffix {
    return [[self defaultsPrefix] stringByAppendingString:suffix];
}

- (void)loadSettings {
    NSUserDefaults *d = NSUserDefaults.standardUserDefaults;
    VFFilterSettings p = VFFilterPresetDefaults();

    id enabled = [d objectForKey:[self defaultsKey:@"filterEnabled"]];
    self.settings = VFFilterSettingsMake(
        enabled ? [enabled boolValue] : p.enabled,
        [d objectForKey:[self defaultsKey:@"contrast"]] ? [d floatForKey:[self defaultsKey:@"contrast"]] : p.contrast,
        [d objectForKey:[self defaultsKey:@"saturation"]] ? [d floatForKey:[self defaultsKey:@"saturation"]] : p.saturation,
        [d objectForKey:[self defaultsKey:@"exposure"]] ? [d floatForKey:[self defaultsKey:@"exposure"]] : p.exposure,
        [d objectForKey:[self defaultsKey:@"sharpen"]] ? [d floatForKey:[self defaultsKey:@"sharpen"]] : p.sharpen,
        [d objectForKey:[self defaultsKey:@"highlights"]] ? [d floatForKey:[self defaultsKey:@"highlights"]] : p.highlights,
        [d objectForKey:[self defaultsKey:@"motionBlur"]] ? [d floatForKey:[self defaultsKey:@"motionBlur"]] : p.motionBlur
    );
}

- (void)saveSettings {
    NSUserDefaults *d = NSUserDefaults.standardUserDefaults;
    VFFilterSettings s = self.settings;
    [d setBool:s.enabled forKey:[self defaultsKey:@"filterEnabled"]];
    [d setFloat:s.contrast forKey:[self defaultsKey:@"contrast"]];
    [d setFloat:s.saturation forKey:[self defaultsKey:@"saturation"]];
    [d setFloat:s.exposure forKey:[self defaultsKey:@"exposure"]];
    [d setFloat:s.sharpen forKey:[self defaultsKey:@"sharpen"]];
    [d setFloat:s.highlights forKey:[self defaultsKey:@"highlights"]];
    [d setFloat:s.motionBlur forKey:[self defaultsKey:@"motionBlur"]];
}

- (UIWindowScene *)activeWindowScene API_AVAILABLE(ios(13.0)) {
    UIWindowScene *fallback = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        UIWindowScene *ws = (UIWindowScene *)scene;
        if (scene.activationState == UISceneActivationStateForegroundActive) return ws;
        if (!fallback && scene.activationState == UISceneActivationStateForegroundInactive) fallback = ws;
    }
    return fallback;
}

- (void)start {
    if (self.started) return;
    self.started = YES;
    [self loadSettings];

    NSNotificationCenter *nc = NSNotificationCenter.defaultCenter;
    [nc addObserver:self selector:@selector(sceneChanged:) name:UIApplicationDidBecomeActiveNotification object:nil];
    [nc addObserver:self selector:@selector(sceneChanged:) name:UIDeviceOrientationDidChangeNotification object:nil];
    if (@available(iOS 13.0, *)) {
        [nc addObserver:self selector:@selector(sceneChanged:) name:UISceneDidActivateNotification object:nil];
    }
    [UIDevice.currentDevice beginGeneratingDeviceOrientationNotifications];

    [self createWindowIfNeeded];
    [[VideoHook sharedInstance] updateFilterSettings:self.settings];
}

- (void)stop {
    if (!self.started) return;
    self.started = NO;
    [NSNotificationCenter.defaultCenter removeObserver:self];
    [UIDevice.currentDevice endGeneratingDeviceOrientationNotifications];
    self.overlayWindow.hidden = YES;
    self.overlayWindow = nil;
    self.rootController = nil;
}

- (void)sceneChanged:(NSNotification *)note {
    (void)note;
    dispatch_async(dispatch_get_main_queue(), ^{
        [self createWindowIfNeeded];
        [self layoutOverlayAnimated:YES];
    });
}

- (void)createWindowIfNeeded {
    if (self.overlayWindow) {
        if (@available(iOS 13.0, *)) {
            UIWindowScene *scene = [self activeWindowScene];
            if (scene && self.overlayWindow.windowScene != scene) self.overlayWindow.windowScene = scene;
        }
        return;
    }

    VFMenuWindow *window = nil;
    if (@available(iOS 13.0, *)) {
        UIWindowScene *scene = [self activeWindowScene];
        if (!scene) return;
        window = [[VFMenuWindow alloc] initWithWindowScene:scene];
        window.frame = scene.coordinateSpace.bounds;
    } else {
        window = [[VFMenuWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    }
    window.backgroundColor = UIColor.clearColor;
    window.windowLevel = UIWindowLevelAlert + 2.0;
    window.hidden = NO;

    VFMenuRootController *root = [VFMenuRootController new];
    root.menu = self;
    root.view.backgroundColor = UIColor.clearColor;
    window.rootViewController = root;

    self.overlayWindow = window;
    self.rootController = root;
    [self buildUI];
    [self restoreButtonPosition];
    [self layoutOverlayAnimated:NO];
}

- (void)buildUI {
    UIView *host = self.rootController.view;

    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(16, 90, VFMenuButtonSize, VFMenuButtonSize);
    button.backgroundColor = [UIColor colorWithWhite:0.08 alpha:0.76];
    button.layer.cornerRadius = VFMenuButtonSize * 0.5;
    button.layer.borderWidth = 1.0;
    button.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.14].CGColor;
    button.tintColor = UIColor.whiteColor;
    button.titleLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightBold];
    [button setTitle:@"VF" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    [host addSubview:button];
    self.floatingButton = button;

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleButtonPan:)];
    [button addGestureRecognizer:pan];

    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemChromeMaterialDark];
    UIVisualEffectView *panel = [[UIVisualEffectView alloc] initWithEffect:blur];
    panel.layer.cornerRadius = 14.0;
    panel.layer.masksToBounds = YES;
    panel.layer.borderWidth = 1.0;
    panel.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.10].CGColor;
    panel.hidden = YES;
    panel.alpha = 0.0;
    [host addSubview:panel];
    self.panel = panel;

    UILabel *title = [UILabel new];
    title.translatesAutoresizingMaskIntoConstraints = NO;
    title.text = @"VIDEO FILTER";
    title.textColor = UIColor.whiteColor;
    title.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightBold];
    [panel.contentView addSubview:title];

    __weak typeof(self) weakSelf = self;
    VFToggleItem *filter = [[VFToggleItem alloc] initWithTitle:@"FILTER"
                                                     initialOn:self.settings.enabled
                                                      onChange:^(BOOL enabled) {
        [weakSelf setFilterEnabled:enabled];
    }];
    self.filterToggle = filter;

    self.contrastItem = [[VFSliderItem alloc] initWithTitle:@"Contrast" minimum:-100 maximum:100 initialValue:self.settings.contrast percent:NO onChange:^(float v) {
        [weakSelf setFloatSetting:v field:0];
    }];
    self.saturationItem = [[VFSliderItem alloc] initWithTitle:@"Saturation" minimum:-100 maximum:100 initialValue:self.settings.saturation percent:NO onChange:^(float v) {
        [weakSelf setFloatSetting:v field:1];
    }];
    self.exposureItem = [[VFSliderItem alloc] initWithTitle:@"Exposure" minimum:-100 maximum:100 initialValue:self.settings.exposure percent:NO onChange:^(float v) {
        [weakSelf setFloatSetting:v field:2];
    }];
    self.sharpenItem = [[VFSliderItem alloc] initWithTitle:@"Sharpen" minimum:0 maximum:100 initialValue:self.settings.sharpen percent:NO onChange:^(float v) {
        [weakSelf setFloatSetting:v field:3];
    }];
    self.highlightsItem = [[VFSliderItem alloc] initWithTitle:@"Highlights" minimum:-100 maximum:100 initialValue:self.settings.highlights percent:NO onChange:^(float v) {
        [weakSelf setFloatSetting:v field:4];
    }];
    self.motionBlurItem = [[VFSliderItem alloc] initWithTitle:@"Motion Blur" minimum:0 maximum:20 initialValue:self.settings.motionBlur percent:YES onChange:^(float v) {
        [weakSelf setFloatSetting:v field:5];
    }];

    UIButton *reset = [UIButton buttonWithType:UIButtonTypeSystem];
    reset.translatesAutoresizingMaskIntoConstraints = NO;
    [reset setTitle:@"RESET" forState:UIControlStateNormal];
    reset.titleLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightSemibold];
    reset.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.08];
    reset.layer.cornerRadius = 8.0;
    [reset addTarget:self action:@selector(resetAdjustments) forControlEvents:UIControlEventTouchUpInside];
    [reset.heightAnchor constraintEqualToConstant:34.0].active = YES;

    UIView *resetWrap = [UIView new];
    resetWrap.translatesAutoresizingMaskIntoConstraints = NO;
    [resetWrap.heightAnchor constraintEqualToConstant:42.0].active = YES;
    [resetWrap addSubview:reset];
    [NSLayoutConstraint activateConstraints:@[
        [reset.leadingAnchor constraintEqualToAnchor:resetWrap.leadingAnchor],
        [reset.trailingAnchor constraintEqualToAnchor:resetWrap.trailingAnchor],
        [reset.centerYAnchor constraintEqualToAnchor:resetWrap.centerYAnchor]
    ]];

    VFPage *page = [[VFPage alloc] initWithItems:@[
        filter,
        self.contrastItem,
        self.saturationItem,
        self.exposureItem,
        self.sharpenItem,
        self.highlightsItem,
        self.motionBlurItem,
        resetWrap
    ]];
    [panel.contentView addSubview:page];

    [NSLayoutConstraint activateConstraints:@[
        [title.leadingAnchor constraintEqualToAnchor:panel.contentView.leadingAnchor constant:14.0],
        [title.trailingAnchor constraintEqualToAnchor:panel.contentView.trailingAnchor constant:-14.0],
        [title.topAnchor constraintEqualToAnchor:panel.contentView.topAnchor constant:10.0],
        [title.heightAnchor constraintEqualToConstant:22.0],
        [page.leadingAnchor constraintEqualToAnchor:panel.contentView.leadingAnchor constant:14.0],
        [page.trailingAnchor constraintEqualToAnchor:panel.contentView.trailingAnchor constant:-14.0],
        [page.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:4.0],
        [page.bottomAnchor constraintEqualToAnchor:panel.contentView.bottomAnchor constant:-10.0]
    ]];
}

- (void)setFilterEnabled:(BOOL)enabled {
    VFFilterSettings s = self.settings;
    s.enabled = enabled;
    self.settings = s;
    [self saveSettings];
    [[VideoHook sharedInstance] updateFilterSettings:s];
}

- (void)setFloatSetting:(float)value field:(NSInteger)field {
    VFFilterSettings s = self.settings;
    switch (field) {
        case 0: s.contrast = value; break;
        case 1: s.saturation = value; break;
        case 2: s.exposure = value; break;
        case 3: s.sharpen = value; break;
        case 4: s.highlights = value; break;
        case 5: s.motionBlur = value; break;
        default: return;
    }
    self.settings = s;
    [self saveSettings];
    [[VideoHook sharedInstance] updateFilterSettings:s];
}

- (void)resetAdjustments {
    BOOL enabled = self.settings.enabled;
    self.settings = VFFilterSettingsZeroed(enabled);
    [self.contrastItem setValue:0 animated:YES notify:NO];
    [self.saturationItem setValue:0 animated:YES notify:NO];
    [self.exposureItem setValue:0 animated:YES notify:NO];
    [self.sharpenItem setValue:0 animated:YES notify:NO];
    [self.highlightsItem setValue:0 animated:YES notify:NO];
    [self.motionBlurItem setValue:0 animated:YES notify:NO];
    [self saveSettings];
    [[VideoHook sharedInstance] updateFilterSettings:self.settings];
    [[VideoHook sharedInstance] resetTemporalHistory];
}

- (UIEdgeInsets)safeInsets {
    if (@available(iOS 11.0, *)) return self.rootController.view.safeAreaInsets;
    return UIEdgeInsetsZero;
}

- (CGRect)safeButtonRect {
    CGRect bounds = self.rootController.view.bounds;
    UIEdgeInsets i = [self safeInsets];
    CGFloat minX = i.left + VFMenuMargin;
    CGFloat minY = i.top + VFMenuMargin;
    CGFloat maxX = CGRectGetWidth(bounds) - i.right - VFMenuMargin - VFMenuButtonSize;
    CGFloat maxY = CGRectGetHeight(bounds) - i.bottom - VFMenuMargin - VFMenuButtonSize;
    maxX = MAX(minX, maxX);
    maxY = MAX(minY, maxY);
    return CGRectMake(minX, minY, maxX - minX, maxY - minY);
}

- (CGPoint)clampButtonOrigin:(CGPoint)origin {
    CGRect r = [self safeButtonRect];
    origin.x = MIN(MAX(origin.x, CGRectGetMinX(r)), CGRectGetMaxX(r));
    origin.y = MIN(MAX(origin.y, CGRectGetMinY(r)), CGRectGetMaxY(r));
    return origin;
}

- (void)handleButtonPan:(UIPanGestureRecognizer *)pan {
    UIView *host = self.rootController.view;
    CGPoint translation = [pan translationInView:host];
    CGPoint origin = self.floatingButton.frame.origin;
    origin.x += translation.x;
    origin.y += translation.y;
    self.floatingButton.frame = (CGRect){[self clampButtonOrigin:origin], self.floatingButton.frame.size};
    [pan setTranslation:CGPointZero inView:host];

    if (pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled) {
        [self saveButtonPosition];
        [self layoutPanelOnlyAnimated:YES];
    }
}

- (void)saveButtonPosition {
    CGRect r = [self safeButtonRect];
    CGPoint o = self.floatingButton.frame.origin;
    CGFloat x = CGRectGetWidth(r) > 0.0 ? (o.x - CGRectGetMinX(r)) / CGRectGetWidth(r) : 0.0;
    CGFloat y = CGRectGetHeight(r) > 0.0 ? (o.y - CGRectGetMinY(r)) / CGRectGetHeight(r) : 0.0;
    NSUserDefaults *d = NSUserDefaults.standardUserDefaults;
    [d setFloat:(float)MIN(MAX(x, 0.0), 1.0) forKey:[self defaultsKey:@"buttonX"]];
    [d setFloat:(float)MIN(MAX(y, 0.0), 1.0) forKey:[self defaultsKey:@"buttonY"]];
}

- (void)restoreButtonPosition {
    NSUserDefaults *d = NSUserDefaults.standardUserDefaults;
    id xObj = [d objectForKey:[self defaultsKey:@"buttonX"]];
    id yObj = [d objectForKey:[self defaultsKey:@"buttonY"]];
    if (!xObj || !yObj) return;

    CGRect r = [self safeButtonRect];
    CGFloat x = MIN(MAX([xObj floatValue], 0.0f), 1.0f);
    CGFloat y = MIN(MAX([yObj floatValue], 0.0f), 1.0f);
    CGPoint o = CGPointMake(CGRectGetMinX(r) + x * CGRectGetWidth(r),
                            CGRectGetMinY(r) + y * CGRectGetHeight(r));
    self.floatingButton.frame = (CGRect){[self clampButtonOrigin:o], self.floatingButton.frame.size};
}

- (void)togglePanel {
    self.panelOpen = !self.panelOpen;
    if (self.panelOpen) self.panel.hidden = NO;
    [self layoutPanelOnlyAnimated:NO];

    [UIView animateWithDuration:0.18 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        self.panel.alpha = self.panelOpen ? 1.0 : 0.0;
        self.panel.transform = self.panelOpen ? CGAffineTransformIdentity : CGAffineTransformMakeScale(0.96, 0.96);
    } completion:^(BOOL finished) {
        (void)finished;
        if (!self.panelOpen) self.panel.hidden = YES;
    }];
}

- (CGRect)panelFrameForButtonFrame:(CGRect)buttonFrame {
    CGRect bounds = self.rootController.view.bounds;
    UIEdgeInsets i = [self safeInsets];
    CGFloat usableWidth = MAX(180.0, CGRectGetWidth(bounds) - i.left - i.right - VFMenuMargin * 2.0);
    CGFloat usableHeight = MAX(160.0, CGRectGetHeight(bounds) - i.top - i.bottom - VFMenuMargin * 2.0);
    CGFloat w = MIN(VFMenuPanelWidth, usableWidth);
    CGFloat h = MIN(VFMenuPanelHeight, usableHeight);

    CGFloat rightSpace = CGRectGetWidth(bounds) - i.right - CGRectGetMaxX(buttonFrame) - VFMenuMargin;
    CGFloat leftSpace = CGRectGetMinX(buttonFrame) - i.left - VFMenuMargin;
    CGFloat x = rightSpace >= w ? CGRectGetMaxX(buttonFrame) + VFMenuMargin
                               : (leftSpace >= w ? CGRectGetMinX(buttonFrame) - VFMenuMargin - w
                                                 : i.left + VFMenuMargin);
    CGFloat y = CGRectGetMidY(buttonFrame) - h * 0.5;
    CGFloat minY = i.top + VFMenuMargin;
    CGFloat maxY = CGRectGetHeight(bounds) - i.bottom - VFMenuMargin - h;
    y = MIN(MAX(y, minY), MAX(minY, maxY));
    return CGRectIntegral(CGRectMake(x, y, w, h));
}

- (void)layoutPanelOnlyAnimated:(BOOL)animated {
    if (!self.panel || !self.floatingButton) return;
    CGRect target = [self panelFrameForButtonFrame:self.floatingButton.frame];
    void (^changes)(void) = ^{ self.panel.frame = target; };
    if (animated && !self.panel.hidden) [UIView animateWithDuration:0.15 animations:changes];
    else changes();
}

- (void)layoutOverlayAnimated:(BOOL)animated {
    if (!self.floatingButton) return;
    CGRect bounds = self.rootController.view.bounds;
    if (@available(iOS 13.0, *)) self.overlayWindow.frame = self.overlayWindow.windowScene.coordinateSpace.bounds;
    else self.overlayWindow.frame = bounds;

    CGPoint clamped = [self clampButtonOrigin:self.floatingButton.frame.origin];
    void (^changes)(void) = ^{
        self.floatingButton.frame = (CGRect){clamped, CGSizeMake(VFMenuButtonSize, VFMenuButtonSize)};
        [self layoutPanelOnlyAnimated:NO];
    };
    if (animated) [UIView animateWithDuration:0.18 animations:changes];
    else changes();
    [self saveButtonPosition];
}

@end
