#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Menu.h"
#import "VideoHook.h"
#import "TargetApps.generated.h"

%ctor {
    @autoreleasepool {
        NSString *bundleID = NSBundle.mainBundle.bundleIdentifier;
        if (!VFBundleIDIsAllowed(bundleID)) return;

        dispatch_async(dispatch_get_main_queue(), ^{
            [[VideoHook sharedInstance] start];
            [[VFMenu sharedInstance] start];
        });
    }
}
