# UI base reference

Base/reference project: xelahot/iOS-Mod-Menu-Base
https://github.com/xelahot/iOS-Mod-Menu-Base

The project structure intentionally keeps the same general menu split (`Menu`, `MenuItem`, `ToggleItem`, `SliderItem`, `Page`, `Tweak.xm`) while the implementation here is adapted for the VideoFilter requirements.
