#pragma once

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import "VFTypes.h"

NS_ASSUME_NONNULL_BEGIN

@interface VideoHook : NSObject
+ (instancetype)sharedInstance;
- (void)start;
- (void)stop;
- (void)updateFilterSettings:(VFFilterSettings)settings;
- (void)resetTemporalHistory;
- (void)registerPlayerLayer:(AVPlayerLayer *)layer;
- (void)notifySeekForPlayer:(AVPlayer *)player;
- (void)notifyItemChangedForPlayer:(AVPlayer *)player;
@end

NS_ASSUME_NONNULL_END
