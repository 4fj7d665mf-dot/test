#!/usr/bin/env python3
import sys
from pathlib import Path

if len(sys.argv) != 3:
    raise SystemExit("usage: embed_shaders.py Shaders.metal ShadersEmbedded.inc")

src = Path(sys.argv[1]).read_text(encoding='utf-8')
# C++ raw string delimiter is intentionally uncommon.
delim = 'VF_METAL_SHADER_6F1A'
if f'){delim}"' in src:
    raise SystemExit('shader source collides with raw-string delimiter')

Path(sys.argv[2]).write_text(
    'static const char *kVFMetalShaderSource = R"' + delim + '(' + src + ')' + delim + '";\n',
    encoding='utf-8'
)
print(f"embedded {sys.argv[1]} -> {sys.argv[2]}")
