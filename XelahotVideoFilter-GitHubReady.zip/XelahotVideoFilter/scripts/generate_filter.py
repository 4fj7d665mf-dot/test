#!/usr/bin/env python3
import plistlib
import re
import sys
from pathlib import Path

if len(sys.argv) not in (3, 4):
    raise SystemExit("usage: generate_filter.py TargetApps.plist VideoFilter.plist [TargetApps.generated.h]")

source = Path(sys.argv[1])
plist_out = Path(sys.argv[2])
header_out = Path(sys.argv[3]) if len(sys.argv) == 4 else None

with source.open('rb') as f:
    data = plistlib.load(f)

bundles = data.get('Bundles', [])
if not isinstance(bundles, list) or not all(isinstance(x, str) and x for x in bundles):
    raise SystemExit('TargetApps.plist: Bundles must be an array of non-empty strings')

bundle_re = re.compile(r'^[A-Za-z0-9][A-Za-z0-9.-]*$')
for bundle in bundles:
    if not bundle_re.fullmatch(bundle):
        raise SystemExit(f'TargetApps.plist: invalid Bundle ID: {bundle!r}')

# Stable de-duplication.
bundles = list(dict.fromkeys(bundles))

payload = {'Filter': {'Bundles': bundles}}
with plist_out.open('wb') as f:
    plistlib.dump(payload, f, fmt=plistlib.FMT_XML, sort_keys=False)
print(f"generated {plist_out} for {len(bundles)} bundle(s)")

if header_out is not None:
    objc_items = ',\n        '.join('@"' + b.replace('\\', '\\\\').replace('"', '\\"') + '"' for b in bundles)
    if objc_items:
        array_body = f'@[\n        {objc_items}\n    ]'
    else:
        array_body = '@[]'
    header = f'''// Auto-generated from TargetApps.plist. Do not edit by hand.\n#pragma once\n\nstatic inline NSArray<NSString *> *VFTargetBundleIDs(void) {{\n    static NSArray<NSString *> *ids;\n    static dispatch_once_t onceToken;\n    dispatch_once(&onceToken, ^{{\n        ids = {array_body};\n    }});\n    return ids;\n}}\n\nstatic inline BOOL VFBundleIDIsAllowed(NSString *bundleID) {{\n    if (bundleID.length == 0) return NO;\n    return [VFTargetBundleIDs() containsObject:bundleID];\n}}\n'''
    header_out.write_text(header, encoding='utf-8')
    print(f"generated {header_out} for {len(bundles)} bundle(s)")
